import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class HomePage {

	 JFrame HomePage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage window = new HomePage();
					window.HomePage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HomePage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		HomePage = new JFrame();
		HomePage.getContentPane().setBackground(new Color(175, 238, 238));
		HomePage.setBounds(100, 100, 770, 593);
		HomePage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		HomePage.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 756, 10);
		HomePage.getContentPane().add(panel);
		
		JButton btnNewButton = new JButton("User");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserTable uf=new UserTable();
				uf.UserFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnNewButton.setBounds(286, 169, 107, 38);
		HomePage.getContentPane().add(btnNewButton);
		
		JButton btnPolice = new JButton("Police");
		btnPolice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PoliceTable pf=new PoliceTable();
				pf.PoliceFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnPolice.setBounds(84, 243, 107, 38);
		HomePage.getContentPane().add(btnPolice);
		
		JButton btnCriminal = new JButton("Criminal");
		btnCriminal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CriminalTable cmt=new CriminalTable();
				cmt.CriminalFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnCriminal.setBounds(493, 243, 107, 38);
		HomePage.getContentPane().add(btnCriminal);
		
		JButton btnCrime = new JButton("Crime");
		btnCrime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrimeTable ct=new CrimeTable();
				ct.CrimeFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnCrime.setBounds(84, 333, 107, 38);
		HomePage.getContentPane().add(btnCrime);
		
		JButton btnJudgement = new JButton("Judgement");
		btnJudgement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JudgementTable jdf=new JudgementTable();
				jdf.JudgementFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnJudgement.setBounds(493, 333, 107, 38);
		HomePage.getContentPane().add(btnJudgement);
		
		JButton btnJail = new JButton("Jail");
		btnJail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JailTable jt=new JailTable();
				jt.JailFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnJail.setBounds(84, 433, 107, 38);
		HomePage.getContentPane().add(btnJail);
		
		JButton btnSuspect = new JButton("Suspect");
		btnSuspect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SuspectTable spt=new SuspectTable();
				spt.SuspectFrame.setVisible(true);
				HomePage.dispose();
			}
		});
		btnSuspect.setBounds(493, 422, 107, 38);
		HomePage.getContentPane().add(btnSuspect);
		
		JLabel lblNewLabel = new JLabel("CRIMINAL DATABASE MANAGEMENT SYSTEM");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel.setBounds(117, 36, 546, 99);
		HomePage.getContentPane().add(lblNewLabel);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
