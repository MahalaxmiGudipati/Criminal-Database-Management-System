import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SuspectTable {

  JFrame SuspectFrame;
	private JTextField txt_id;
	private JTextField txt_name;
	private JTextField txt_city;
	private JTextField txt_state;
	private JTable table;
	private int Personid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SuspectTable window = new SuspectTable();
					window.SuspectFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SuspectTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		SuspectFrame = new JFrame();
		SuspectFrame.getContentPane().setBackground(new Color(175, 238, 238));
		SuspectFrame.setBounds(100, 100, 975, 634);
		SuspectFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SuspectFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 985, 10);
		SuspectFrame.getContentPane().add(panel);
		
		JLabel id = new JLabel("ID :");
		id.setFont(new Font("Tahoma", Font.PLAIN, 13));
		id.setBounds(37, 82, 80, 34);
		SuspectFrame.getContentPane().add(id);
		
		JLabel name = new JLabel("Name :");
		name.setFont(new Font("Tahoma", Font.PLAIN, 13));
		name.setBounds(37, 152, 80, 34);
		SuspectFrame.getContentPane().add(name);
		
		JLabel city = new JLabel("City :");
		city.setFont(new Font("Tahoma", Font.PLAIN, 13));
		city.setBounds(37, 221, 80, 34);
		SuspectFrame.getContentPane().add(city);
		
		JLabel state = new JLabel("State :");
		state.setFont(new Font("Tahoma", Font.PLAIN, 13));
		state.setBounds(37, 284, 80, 34);
		SuspectFrame.getContentPane().add(state);
		
		txt_id = new JTextField();
		txt_id.setColumns(10);
		txt_id.setBounds(127, 84, 170, 34);
		SuspectFrame.getContentPane().add(txt_id);
		
		txt_name = new JTextField();
		txt_name.setBounds(127, 154, 170, 34);
		SuspectFrame.getContentPane().add(txt_name);
		txt_name.setColumns(10);
		
		txt_city = new JTextField();
		txt_city.setColumns(10);
		txt_city.setBounds(127, 223, 170, 34);
		SuspectFrame.getContentPane().add(txt_city);
		
		txt_state = new JTextField();
		txt_state.setColumns(10);
		txt_state.setBounds(127, 286, 170, 34);
		SuspectFrame.getContentPane().add(txt_state);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(325, 54, 602, 512);
		SuspectFrame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Personid=Integer.parseInt((String) table.getValueAt(table.getSelectedRow(),0));
					 conn c1 = new conn();
					 String str="select * from suspecttable where id="+Personid;
					 ResultSet rs = c1.s.executeQuery(str); 
					 if(rs.next())
					 {
						 txt_name.setText(rs.getString(2));
						 txt_city.setText(rs.getString(3));
						 txt_state.setText(rs.getString(4));
					 }
					}
					  catch (Exception exception) {
		                    exception.printStackTrace();
		                }
				DefaultTableModel model=(DefaultTableModel)table.getModel();
	      			
	      		String id=model.getValueAt(table.getSelectedRow(), 0).toString();
	      		String name=model.getValueAt(table.getSelectedRow(), 1).toString();
	      		String city=model.getValueAt(table.getSelectedRow(), 2).toString();
	      		String state=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		
	      		txt_id.setText(id);
	      		txt_name.setText(name);
	      		txt_city.setText(city);
	      		txt_state.setText(state);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Name", "City", "State"
			}
		));
		scrollPane.setViewportView(table);
		
		final JButton btnInsert = new JButton("Submit");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
	               	 conn c2 = new conn();
	               	 String id = txt_id.getText();
	               	    String name = txt_name.getText();
	                    String city = txt_city.getText();
	                    String state = txt_state.getText();
	                  
	                String str =  "INSERT INTO suspecttable values('" + id + "','" + name + "','" + city +  "','"  + state+ "')";
	                if(txt_id.getText().equals("") || txt_name.getText().equals("") || txt_city.getText().equals("") || txt_state.getText().equals(""))
					{
						JOptionPane.showMessageDialog(btnInsert,"Please Enter All Data");
					}
	               else {
	                    ResultSet rs = c2.s.executeQuery(str);
	                    String data[]= {txt_id.getText(),txt_name.getText(),txt_city.getText(),txt_state.getText()};
	                    DefaultTableModel model=(DefaultTableModel)table.getModel();
	    				model.addRow(data);
	    				JOptionPane.showMessageDialog(btnInsert, "Added Successfully");
						}
	            	txt_id.setText("");
	            	txt_name.setText("");
				    txt_city.setText("");
					txt_state.setText("");
	               }
	               catch (Exception exception) {
	                   exception.printStackTrace();
	               }	
			}
		});
		btnInsert.setBounds(22, 367, 95, 43);
		SuspectFrame.getContentPane().add(btnInsert);
		
		final JButton btnUpdate = new JButton("Modify");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Personid!=0)
				{
					String name=txt_name.getText();
					String city=txt_city.getText();
					String state=txt_state.getText();
					
					try {  
						 conn c1 = new conn();
						 String sql="update suspecttable set name='"+name+"',city='"+city+"',state='"+state+"' where id="+Personid;
						  ResultSet rs = c1.s.executeQuery(sql);  
							JOptionPane.showMessageDialog(btnUpdate, "Updated Successfully");
						    int row=table.getSelectedRow();
			                String cell=table.getModel().getValueAt(row, 0).toString();
			                 String str1 =  "DELETE FROM suspecttable WHERE id ="+cell;
			                 conn c2 = new conn();
			                     ResultSet rs1 = c2.s.executeQuery(str1);  
			                    DefaultTableModel model=(DefaultTableModel)table.getModel();
			                    model.removeRow(table.getSelectedRow());

						     String data[]= {txt_id.getText(),txt_name.getText(),txt_city.getText(),txt_state.getText()};
		     				model.addRow(data);
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					} 
				}	
			}
		});
		btnUpdate.setBounds(176, 367, 99, 43);
		SuspectFrame.getContentPane().add(btnUpdate);
		
		final JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
		                int row=table.getSelectedRow();
		                String cell=table.getModel().getValueAt(row, 0).toString();
		                 String str =  "DELETE FROM suspecttable WHERE id ="+cell; 
		                     ResultSet rs = c1.s.executeQuery(str);  
		                    DefaultTableModel model=(DefaultTableModel)table.getModel();
		                    model.removeRow(table.getSelectedRow());
		     				JOptionPane.showMessageDialog(btnDelete, "Deleted Successfully");
		     				
		     				txt_id.setText("");
		     				txt_name.setText("");
						    txt_city.setText("");
							txt_state.setText("");
		                }
		                catch (Exception exception) {
		                    exception.printStackTrace();
		                }
			}
		});
		btnDelete.setBounds(22, 448, 95, 43);
		SuspectFrame.getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage hp=new HomePage();
				hp.HomePage.setVisible(true);
				SuspectFrame.dispose();
			}
		});
		btnBack.setBounds(105, 515, 99, 43);
		SuspectFrame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel = new JLabel("SUSPECT DATABASE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(45, 33, 252, 34);
		SuspectFrame.getContentPane().add(lblNewLabel);
		
		JButton btnAlldetails = new JButton("AllDetails");
		btnAlldetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
	                 String str =  "select * from suspecttable";
	                     ResultSet rs = c1.s.executeQuery(str);  
	                     DefaultTableModel model=(DefaultTableModel)table.getModel();
             			model.setRowCount(0);
             			  while(rs.next())
             			  {
             				  model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
             			  }
	                }
	                catch (Exception exception) {
	                    exception.printStackTrace();
	                }
			}
		});
		btnAlldetails.setBounds(176, 448, 99, 43);
		SuspectFrame.getContentPane().add(btnAlldetails);
	}

}
