import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class CrimeTable {

	 JFrame CrimeFrame;
	 private final JPanel panel = new JPanel();
	 private JTextField txt_id;
	 private JTextField txt_category;
	 private JTextField txt_place;
	 private JTextField txt_FirID;
	 private JTextField txt_FirType;
	 private JTextField txt_FirDate;
	 private JTable table;
	 private int Personid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrimeTable window = new CrimeTable();
					window.CrimeFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CrimeTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		CrimeFrame = new JFrame();
		CrimeFrame.getContentPane().setBackground(new Color(175, 238, 238));
		CrimeFrame.getContentPane().setLayout(null);
		panel.setBounds(0, 0, 964, 10);
		CrimeFrame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel id = new JLabel("ID :");
		id.setFont(new Font("Tahoma", Font.PLAIN, 13));
		id.setBounds(22, 102, 91, 29);
		CrimeFrame.getContentPane().add(id);
		
		JLabel category = new JLabel("Category :");
		category.setFont(new Font("Tahoma", Font.PLAIN, 13));
		category.setBounds(10, 141, 91, 29);
		CrimeFrame.getContentPane().add(category);
		
		JLabel place = new JLabel("Place :");
		place.setFont(new Font("Tahoma", Font.PLAIN, 13));
		place.setBounds(22, 180, 91, 29);
		CrimeFrame.getContentPane().add(place);
		
		JLabel FirID = new JLabel("FIR_ID :");
		FirID.setFont(new Font("Tahoma", Font.PLAIN, 13));
		FirID.setBounds(22, 219, 91, 29);
		CrimeFrame.getContentPane().add(FirID);
		
		JLabel FirType = new JLabel("FIR_Type :");
		FirType.setFont(new Font("Tahoma", Font.PLAIN, 13));
		FirType.setBounds(22, 260, 91, 29);
		CrimeFrame.getContentPane().add(FirType);
		
		JLabel FirDate = new JLabel("");
		FirDate.setBounds(22, 321, 57, 29);
		CrimeFrame.getContentPane().add(FirDate);
		
		JLabel lblFirdate = new JLabel("FIR_Date :");
		lblFirdate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFirdate.setBounds(22, 303, 91, 29);
		CrimeFrame.getContentPane().add(lblFirdate);
		
		txt_id = new JTextField();
		txt_id.setBounds(91, 112, 176, 19);
		CrimeFrame.getContentPane().add(txt_id);
		txt_id.setColumns(10);
		
		txt_category = new JTextField();
		txt_category.setColumns(10);
		txt_category.setBounds(91, 151, 176, 19);
		CrimeFrame.getContentPane().add(txt_category);
		
		txt_place = new JTextField();
		txt_place.setColumns(10);
		txt_place.setBounds(91, 186, 176, 19);
		CrimeFrame.getContentPane().add(txt_place);
		
		txt_FirID = new JTextField();
		txt_FirID.setColumns(10);
		txt_FirID.setBounds(91, 225, 176, 19);
		CrimeFrame.getContentPane().add(txt_FirID);
		
		txt_FirType = new JTextField();
		txt_FirType.setColumns(10);
		txt_FirType.setBounds(91, 266, 176, 19);
		CrimeFrame.getContentPane().add(txt_FirType);
		
		txt_FirDate = new JTextField();
		txt_FirDate.setColumns(10);
		txt_FirDate.setBounds(91, 309, 176, 19);
		CrimeFrame.getContentPane().add(txt_FirDate);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(291, 31, 651, 530);
		CrimeFrame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Personid=Integer.parseInt((String) table.getValueAt(table.getSelectedRow(),0));
					 conn c1 = new conn();
					 String str="select * from crimetable where id="+Personid;
					 ResultSet rs = c1.s.executeQuery(str); 
					 if(rs.next())
					 {
						 txt_category.setText(rs.getString(2));
						 txt_place.setText(rs.getString(3));
						 txt_FirID.setText(rs.getString(4));
						 txt_FirType.setText(rs.getString(5));
						 txt_FirDate.setText(rs.getString(6));
					 }
					}
					  catch (Exception exception) {
		                    exception.printStackTrace();
		                }
				DefaultTableModel model=(DefaultTableModel)table.getModel();
	      		
	      		String id=model.getValueAt(table.getSelectedRow(), 0).toString();
	      		String category=model.getValueAt(table.getSelectedRow(), 1).toString();
	      		String place=model.getValueAt(table.getSelectedRow(), 2).toString();
	      		String Firid=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		String FirType=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		String FirDate=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		
	      		txt_id.setText(id);
	      		txt_category.setText(category);
	      		txt_place.setText(place);
	      		txt_FirID.setText(Firid);
	      		txt_FirType.setText(FirType);
	      		txt_FirDate.setText(FirDate);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Category", "Place", "FIR_Id", "FIR_Type", "Crimedate"
			}
		));
		scrollPane.setViewportView(table);
		
		final JButton btnInsert = new JButton("Submit");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
	               	 conn c2 = new conn();
	               	 String id = txt_id.getText();
	                    String category = txt_category.getText();
	                    String place = txt_place.getText();
	                    String FirID = txt_FirID.getText();
	                    String FirType = txt_FirType.getText();
	                    String FirDate = txt_FirDate.getText();
	                    
	                String str =  "INSERT INTO crimetable values('" + id + "','" + category + "','" + place + "','" + FirID + "','" + FirType +  "','"
	                 + FirDate+ "')";
	            	if(txt_id.getText().equals("") || txt_category.getText().equals("") || txt_place.getText().equals("")|| txt_FirID.getText().equals("")|| txt_FirType.getText().equals("")|| txt_FirDate.getText().equals(""))
					{
						JOptionPane.showMessageDialog(btnInsert,"Please Enter All Data");
					}
	               else {
	                    ResultSet rs = c2.s.executeQuery(str);  
	                	
						String data[]= {txt_id.getText(),txt_category.getText(),txt_place.getText(),txt_FirID.getText(),txt_FirType.getText(),txt_FirDate.getText()};
						
	                    DefaultTableModel model=(DefaultTableModel)table.getModel();
	    				model.addRow(data);
	    				JOptionPane.showMessageDialog(btnInsert, "Added Successfully");
						}
						txt_id.setText("");
						txt_category.setText("");
						txt_place.setText("");
					    txt_FirID.setText("");
						txt_FirType.setText("");
						txt_FirDate.setText("");
	                
	               }
	               catch (Exception exception) {
	                   exception.printStackTrace();
	               }
			}
		});
		btnInsert.setBounds(22, 373, 85, 38);
		CrimeFrame.getContentPane().add(btnInsert);
		
		final JButton btnUpdate = new JButton("Modify");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Personid!=0)
				{
					String category=txt_category.getText();
					String place=txt_place.getText();
					String Firid=txt_FirID.getText();
					String FirType=txt_FirType.getText();
					String FirDate=txt_FirDate.getText();
					try {  
						 conn c1 = new conn();
						 String sql="update crimetable set category='"+category+"',place='"+place+"',Firid='"+Firid+"',FirType='"+FirType+"',FirDate='"+FirDate+"' where id="+Personid;
						  ResultSet rs = c1.s.executeQuery(sql);  
							JOptionPane.showMessageDialog(btnUpdate, "Updated Successfully");
						    int row=table.getSelectedRow();
			                String cell=table.getModel().getValueAt(row, 0).toString();
			                 String str1 =  "DELETE FROM criminaltable WHERE id ="+cell;
			                 conn c2 = new conn();
			                     ResultSet rs1 = c2.s.executeQuery(str1);  
			                    DefaultTableModel model=(DefaultTableModel)table.getModel();
			                    model.removeRow(table.getSelectedRow());

						     String data[]= {txt_id.getText(),txt_category.getText(),txt_place.getText(),txt_FirID.getText(),txt_FirType.getText(),txt_FirDate.getText()};
		     				model.addRow(data);
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					} 
				}	
			}
		});
		btnUpdate.setBounds(159, 373, 85, 38);
		CrimeFrame.getContentPane().add(btnUpdate);
		
		final JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 conn c1 = new conn();
				 try {
	                	
		                int row=table.getSelectedRow();
		                String cell=table.getModel().getValueAt(row, 0).toString();
		                 String str =  "DELETE FROM crimetable WHERE id ="+cell; 
		                     ResultSet rs = c1.s.executeQuery(str);  
		                    DefaultTableModel model=(DefaultTableModel)table.getModel();
		                    model.removeRow(table.getSelectedRow());
		     				JOptionPane.showMessageDialog(btnDelete, "Deleted Successfully");
		     				
		     				txt_id.setText("");
							txt_category.setText("");
							txt_place.setText("");
						    txt_FirID.setText("");
							txt_FirType.setText("");
							txt_FirDate.setText("");
		                }
		                catch (Exception exception) {
		                    exception.printStackTrace();
		                }
			}
		});
		btnDelete.setBounds(22, 457, 85, 38);
		CrimeFrame.getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage hp=new HomePage();
				hp.HomePage.setVisible(true);
				CrimeFrame.dispose();
			}
		});
		btnBack.setBounds(95, 523, 85, 38);
		CrimeFrame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("CRIME DATABASE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_1.setBounds(46, 31, 235, 61);
		CrimeFrame.getContentPane().add(lblNewLabel_1);
		
		JButton btnAlldetails = new JButton("Alldetails");
		btnAlldetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
	                 String str =  "select * from crimetable";
	                     ResultSet rs = c1.s.executeQuery(str);  
	                     DefaultTableModel model=(DefaultTableModel)table.getModel();
             			model.setRowCount(0);
             			  while(rs.next())
             			  {
             				  model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)});
             			  }
	                }
	                catch (Exception exception) {
	                    exception.printStackTrace();
	                }
			}
		});
		btnAlldetails.setBounds(159, 457, 85, 38);
		CrimeFrame.getContentPane().add(btnAlldetails);
		CrimeFrame.setBackground(new Color(175, 238, 238));
		CrimeFrame.setBounds(100, 100, 978, 632);
		CrimeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
