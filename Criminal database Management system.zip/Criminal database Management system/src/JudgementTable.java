import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JudgementTable {

    JFrame JudgementFrame;
	private JTextField txt_id;
	private JTextField txt_place;
	private JTextField txt_name;
	private JTextField txt_type;
	private JTable table;
	private int Personid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JudgementTable window = new JudgementTable();
					window.JudgementFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JudgementTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		JudgementFrame = new JFrame();
		JudgementFrame.getContentPane().setBackground(new Color(175, 238, 238));
		JudgementFrame.setBounds(100, 100, 976, 623);
		JudgementFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JudgementFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1027, 10);
		JudgementFrame.getContentPane().add(panel);
		
		JLabel id = new JLabel("ID :");
		id.setFont(new Font("Tahoma", Font.PLAIN, 13));
		id.setBounds(47, 78, 87, 40);
		JudgementFrame.getContentPane().add(id);
		
		JLabel place = new JLabel("Place :");
		place.setFont(new Font("Tahoma", Font.PLAIN, 13));
		place.setBounds(47, 128, 87, 40);
		JudgementFrame.getContentPane().add(place);
		
		JLabel name = new JLabel("Name :");
		name.setFont(new Font("Tahoma", Font.PLAIN, 13));
		name.setBounds(47, 188, 87, 40);
		JudgementFrame.getContentPane().add(name);
		
		JLabel type = new JLabel("Type :");
		type.setFont(new Font("Tahoma", Font.PLAIN, 13));
		type.setBounds(47, 248, 87, 40);
		JudgementFrame.getContentPane().add(type);
		
		txt_id = new JTextField();
		txt_id.setBounds(115, 86, 178, 28);
		JudgementFrame.getContentPane().add(txt_id);
		txt_id.setColumns(10);
		
		txt_place = new JTextField();
		txt_place.setColumns(10);
		txt_place.setBounds(115, 140, 178, 28);
		JudgementFrame.getContentPane().add(txt_place);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(115, 200, 178, 28);
		JudgementFrame.getContentPane().add(txt_name);
		
		txt_type = new JTextField();
		txt_type.setColumns(10);
		txt_type.setBounds(115, 260, 178, 28);
		JudgementFrame.getContentPane().add(txt_type);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(349, 40, 578, 496);
		JudgementFrame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Personid=Integer.parseInt((String) table.getValueAt(table.getSelectedRow(),0));
					 conn c1 = new conn();
					 String str="select * from judgementtable where id="+Personid;
					 ResultSet rs = c1.s.executeQuery(str); 
					 if(rs.next())
					 {
						 txt_place.setText(rs.getString(2));
						 txt_name.setText(rs.getString(3));
						 txt_type.setText(rs.getString(4));
					 }
					}
					  catch (Exception exception) {
		                    exception.printStackTrace();
		                }
				DefaultTableModel model=(DefaultTableModel)table.getModel();
	      		
	      		String id=model.getValueAt(table.getSelectedRow(), 0).toString();
	      		String place=model.getValueAt(table.getSelectedRow(), 1).toString();
	      		String name=model.getValueAt(table.getSelectedRow(), 2).toString();
	      		String type=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		
	      		txt_id.setText(id);
	      		txt_place.setText(place);
	      		txt_name.setText(name);
	      		txt_type.setText(type);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Place", "Name", "Type"
			}
		));
		table.setForeground(new Color(0, 0, 0));
		scrollPane.setViewportView(table);
		
		final JButton btnInsert = new JButton("Submit");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
	               	 conn c2 = new conn();
	               	    String id = txt_id.getText();
	                    String place = txt_place.getText();
	                    String name = txt_name.getText();
	                    String type = txt_type.getText();
	                  
	                String str =  "INSERT INTO judgementtable values('" + id + "','" + place + "','" + name +  "','"  + type+ "')";
	            	if(txt_id.getText().equals("") || txt_place.getText().equals("") || txt_name.getText().equals("") || txt_type.getText().equals(""))
					{
						JOptionPane.showMessageDialog(btnInsert,"Please Enter All Data");
					}
	               else {
	                    ResultSet rs = c2.s.executeQuery(str);  
	                    String data[]= {txt_id.getText(),txt_place.getText(),txt_name.getText(),txt_type.getText()};
	    				
	                    DefaultTableModel model=(DefaultTableModel)table.getModel();
	    				model.addRow(data);
	    				JOptionPane.showMessageDialog(btnInsert, "Added Successfully");
						}
	            	txt_id.setText("");
					txt_place.setText("");
				    txt_name.setText("");
					txt_type.setText("");
	                
	               }
	               catch (Exception exception) {
	                   exception.printStackTrace();
	               }	
			}
		});
		btnInsert.setBounds(32, 333, 102, 40);
		JudgementFrame.getContentPane().add(btnInsert);
		
		final JButton btnUpdate = new JButton("Modify");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Personid!=0)
				{
					String place=txt_place.getText();
					String name=txt_name.getText();
					String type=txt_type.getText();
					
					try {  
						 conn c1 = new conn();
						 String sql="update judgementtable set place='"+place+"',name='"+name+"',type='"+type+"' where id="+Personid;
						  ResultSet rs = c1.s.executeQuery(sql);  
							JOptionPane.showMessageDialog(btnUpdate, "Updated Successfully");
						    int row=table.getSelectedRow();
			                String cell=table.getModel().getValueAt(row, 0).toString();
			                 String str1 =  "DELETE FROM judgementtable WHERE id ="+cell;
			                 conn c2 = new conn();
			                     ResultSet rs1 = c2.s.executeQuery(str1);  
			                    DefaultTableModel model=(DefaultTableModel)table.getModel();
			                    model.removeRow(table.getSelectedRow());

						     String data[]= {txt_id.getText(),txt_place.getText(),txt_name.getText(),txt_type.getText()};
		     				model.addRow(data);
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					} 
				}	
			}
		});
		btnUpdate.setBounds(193, 333, 100, 40);
		JudgementFrame.getContentPane().add(btnUpdate);
		
		final JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
		                int row=table.getSelectedRow();
		                String cell=table.getModel().getValueAt(row, 0).toString();
		                 String str =  "DELETE FROM judgementtable WHERE id ="+cell; 
		                     ResultSet rs = c1.s.executeQuery(str);  
		                    DefaultTableModel model=(DefaultTableModel)table.getModel();
		                    model.removeRow(table.getSelectedRow());
		     				JOptionPane.showMessageDialog(btnDelete, "Deleted Successfully");
		     				
		     				txt_id.setText("");
							txt_place.setText("");
						    txt_name.setText("");
							txt_type.setText("");
		                }
		                catch (Exception exception) {
		                    exception.printStackTrace();
		                }
			}
		});
		btnDelete.setBounds(32, 436, 102, 40);
		JudgementFrame.getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage hp=new HomePage();
				hp.HomePage.setVisible(true);
				JudgementFrame.dispose();
			}
		});
		btnBack.setBounds(106, 512, 102, 40);
		JudgementFrame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("JUDGEMENT DATABASE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_1.setBounds(47, 25, 234, 28);
		JudgementFrame.getContentPane().add(lblNewLabel_1);
		
		JButton btnAlldetails = new JButton("AllDetails");
		btnAlldetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
	                 String str =  "select * from judgementtable";
	                     ResultSet rs = c1.s.executeQuery(str);  
	                     DefaultTableModel model=(DefaultTableModel)table.getModel();
             			model.setRowCount(0);
             			  while(rs.next())
             			  {
             				  model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
             			  }
	                }
	                catch (Exception exception) {
	                    exception.printStackTrace();
	                }
			}
		});
		btnAlldetails.setBounds(193, 436, 100, 40);
		JudgementFrame.getContentPane().add(btnAlldetails);
	}
}
