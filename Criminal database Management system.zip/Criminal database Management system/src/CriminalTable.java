import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JRadioButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.regex.Pattern;

public class CriminalTable {

    JFrame CriminalFrame;
	private JTextField txt_id;
	private JTextField txt_name;
	private JTextField txt_mobile;
	private JTextField txt_address;
	private JTable table;
	private JTextField txt_gender;
	private int Personid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CriminalTable window = new CriminalTable();
					window.CriminalFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CriminalTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		CriminalFrame = new JFrame();
		CriminalFrame.getContentPane().setBackground(new Color(175, 238, 238));
		CriminalFrame.setBounds(100, 100, 977, 656);
		CriminalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		CriminalFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 966, 10);
		CriminalFrame.getContentPane().add(panel);
		
		JLabel id = new JLabel("ID :");
		id.setFont(new Font("Tahoma", Font.PLAIN, 13));
		id.setBounds(50, 76, 92, 29);
		CriminalFrame.getContentPane().add(id);
		
		JLabel name = new JLabel("Name :");
		name.setFont(new Font("Tahoma", Font.PLAIN, 13));
		name.setBounds(50, 125, 92, 29);
		CriminalFrame.getContentPane().add(name);
		
		JLabel gender = new JLabel("Gender :");
		gender.setFont(new Font("Tahoma", Font.PLAIN, 13));
		gender.setBounds(50, 177, 92, 29);
		CriminalFrame.getContentPane().add(gender);
		
		final JLabel mobile = new JLabel("MobileNo :");
		mobile.setFont(new Font("Tahoma", Font.PLAIN, 13));
		mobile.setBounds(50, 229, 92, 29);
		CriminalFrame.getContentPane().add(mobile);
		
		JLabel address = new JLabel("Address :");
		address.setFont(new Font("Tahoma", Font.PLAIN, 13));
		address.setBounds(50, 285, 92, 29);
		CriminalFrame.getContentPane().add(address);
		
		txt_id = new JTextField();
		txt_id.setBounds(129, 82, 172, 19);
		CriminalFrame.getContentPane().add(txt_id);
		txt_id.setColumns(10);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(129, 131, 172, 19);
		CriminalFrame.getContentPane().add(txt_name);
		
		txt_mobile = new JTextField();
		txt_mobile.setColumns(10);
		txt_mobile.setBounds(129, 235, 172, 19);
		CriminalFrame.getContentPane().add(txt_mobile);
		
		txt_address = new JTextField();
		txt_address.setColumns(10);
		txt_address.setBounds(129, 291, 172, 19);
		CriminalFrame.getContentPane().add(txt_address);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(357, 42, 566, 530);
		CriminalFrame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Personid=Integer.parseInt((String) table.getValueAt(table.getSelectedRow(),0));
					 conn c1 = new conn();
					 String str="select * from criminaltable where id="+Personid;
					 ResultSet rs = c1.s.executeQuery(str); 
					 if(rs.next())
					 {
						 txt_name.setText(rs.getString(2));
						 txt_gender.setText(rs.getString(3));
						 txt_mobile.setText(rs.getString(4));
						 txt_address.setText(rs.getString(5));
					 }
					}
					  catch (Exception exception) {
		                    exception.printStackTrace();
		                }
				DefaultTableModel model=(DefaultTableModel)table.getModel();
	      		
	      		String id=model.getValueAt(table.getSelectedRow(), 0).toString();
	      		String name=model.getValueAt(table.getSelectedRow(), 1).toString();
	      		String gender=model.getValueAt(table.getSelectedRow(), 2).toString();
	      		String mobile=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		String address=model.getValueAt(table.getSelectedRow(), 4).toString();
	      		
	      		txt_id.setText(id);
	      		txt_name.setText(name);
	      		txt_gender.setText(gender);
	      		txt_mobile.setText(mobile);
	      		txt_address.setText(address);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Name", "Gender", "Mobile", "Address"
			}
		));
		table.setForeground(new Color(0, 0, 0));
		scrollPane.setViewportView(table);
		
		final JButton btnInsert = new JButton("Submit");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
               	 conn c2 = new conn();
               	 String id = txt_id.getText();
                    String name = txt_name.getText();
                    String gender = txt_gender.getText();
                    String mobile = txt_mobile.getText();
                    String address = txt_address.getText();
                    
                String str =  "INSERT INTO criminaltable values('" + id + "','" + name + "','" + gender + "','" + mobile + "','" 
                 + address + "')";
                if(txt_id.getText().equals("") || txt_name.getText().equals("") || txt_gender.getText().equals("")|| txt_mobile.getText().equals("") || txt_address.getText().equals(""))
				{
					JOptionPane.showMessageDialog(btnInsert,"Please Enter All Data");
				}
               else {
                    ResultSet rs = c2.s.executeQuery(str);  
                    String data[]= {txt_id.getText(),txt_name.getText(),txt_gender.getText(),txt_mobile.getText(),txt_address.getText()};
					if(!Pattern.matches("^[0-9]+$",txt_mobile.getText()))
					{
						 JOptionPane.showMessageDialog(btnInsert, "Enter a valid mobile number");
					}else {
                    DefaultTableModel model=(DefaultTableModel)table.getModel();
    				model.addRow(data);
    				JOptionPane.showMessageDialog(btnInsert, "Added Successfully");
					}
    				txt_id.setText("");
					txt_name.setText("");
					txt_gender.setText("");
				    txt_mobile.setText("");
					txt_address.setText("");
                }
               }
               catch (Exception exception) {
                   exception.printStackTrace();
               }
			}
		});
		btnInsert.setBounds(36, 367, 92, 37);
		CriminalFrame.getContentPane().add(btnInsert);
		
		final JButton btnUpdate = new JButton("Modify");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Personid!=0)
				{
					String name=txt_name.getText();
					String gender=txt_gender.getText();
					String mobile=txt_mobile.getText();
					String address=txt_address.getText();
					try {  
						 conn c1 = new conn();
						 String sql="update criminaltable set name='"+name+"',gender='"+gender+"',mobile='"+mobile+"',address='"+address+"' where id="+Personid;
						  ResultSet rs = c1.s.executeQuery(sql);  
							JOptionPane.showMessageDialog(btnUpdate, "Updated Successfully");
						    int row=table.getSelectedRow();
			                String cell=table.getModel().getValueAt(row, 0).toString();
			                 String str1 =  "DELETE FROM criminaltable WHERE id ="+cell;
			                 conn c2 = new conn();
			                     ResultSet rs1 = c2.s.executeQuery(str1);  
			                    DefaultTableModel model=(DefaultTableModel)table.getModel();
			                    model.removeRow(table.getSelectedRow());

						     String data[]= {txt_id.getText(),txt_name.getText(),txt_gender.getText(),txt_mobile.getText(),txt_address.getText()};
		     				model.addRow(data);
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					} 
				}	
			}
		});
		btnUpdate.setBounds(198, 367, 92, 37);
		CriminalFrame.getContentPane().add(btnUpdate);
		
		final JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 conn c1 = new conn();
				 try {
	                	
		                int row=table.getSelectedRow();
		                String cell=table.getModel().getValueAt(row, 0).toString();
		                 String str =  "DELETE FROM criminaltable WHERE id ="+cell; 
		                     ResultSet rs = c1.s.executeQuery(str);  
		                    DefaultTableModel model=(DefaultTableModel)table.getModel();
		                    model.removeRow(table.getSelectedRow());
		     				JOptionPane.showMessageDialog(btnDelete, "Deleted Successfully");
		     				
		     				txt_id.setText("");
							txt_name.setText("");
							txt_gender.setText("");
						    txt_mobile.setText("");
							txt_address.setText("");
		                }
		                catch (Exception exception) {
		                    exception.printStackTrace();
		                }
			}
		});
		btnDelete.setBounds(36, 464, 92, 37);
		CriminalFrame.getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage hp=new HomePage();
				hp.HomePage.setVisible(true);
				CriminalFrame.dispose();
			}
		});
		btnBack.setBounds(129, 535, 92, 37);
		CriminalFrame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel = new JLabel("CRIMINAL DATABASE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(50, 26, 270, 29);
		CriminalFrame.getContentPane().add(lblNewLabel);
		
		txt_gender = new JTextField();
		txt_gender.setColumns(10);
		txt_gender.setBounds(129, 183, 172, 19);
		CriminalFrame.getContentPane().add(txt_gender);
		
		JButton btnAlldetails = new JButton("AllDetails");
		btnAlldetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
	                 String str =  "select * from criminaltable";
	                     ResultSet rs = c1.s.executeQuery(str);  
	                     DefaultTableModel model=(DefaultTableModel)table.getModel();
             			model.setRowCount(0);
             			  while(rs.next())
             			  {
             				  model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
             			  }
	                }
	                catch (Exception exception) {
	                    exception.printStackTrace();
	                }
			}
		});
		btnAlldetails.setBounds(198, 464, 92, 37);
		CriminalFrame.getContentPane().add(btnAlldetails);
	}
}
