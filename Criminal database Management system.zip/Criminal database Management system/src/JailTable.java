import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class JailTable {

	 JFrame JailFrame;
	private JTextField txt_id;
	private JTextField txt_hod;
	private JTextField txt_name;
	private JTextField txt_type;
	private JTextField txt_contact;
	private JTextField txt_address;
	private JTable table;
	private int Personid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JailTable window = new JailTable();
					window.JailFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JailTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		JailFrame = new JFrame();
		JailFrame.getContentPane().setBackground(new Color(175, 238, 238));
		JailFrame.setBounds(100, 100, 976, 628);
		JailFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JailFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 957, 10);
		JailFrame.getContentPane().add(panel);
		
		JLabel id = new JLabel("ID :");
		id.setFont(new Font("Tahoma", Font.PLAIN, 13));
		id.setBounds(33, 89, 79, 24);
		JailFrame.getContentPane().add(id);
		
		JLabel hod = new JLabel("HeadOfDept :");
		hod.setFont(new Font("Tahoma", Font.PLAIN, 13));
		hod.setBounds(33, 132, 79, 24);
		JailFrame.getContentPane().add(hod);
		
		JLabel name = new JLabel("Name :");
		name.setFont(new Font("Tahoma", Font.PLAIN, 13));
		name.setBounds(33, 172, 79, 24);
		JailFrame.getContentPane().add(name);
		
		JLabel type = new JLabel("Type :");
		type.setFont(new Font("Tahoma", Font.PLAIN, 13));
		type.setBounds(33, 215, 79, 24);
		JailFrame.getContentPane().add(type);
		
		JLabel contact = new JLabel("Contact :");
		contact.setFont(new Font("Tahoma", Font.PLAIN, 13));
		contact.setBounds(33, 256, 79, 24);
		JailFrame.getContentPane().add(contact);
		
		JLabel address = new JLabel("Address :");
		address.setFont(new Font("Tahoma", Font.PLAIN, 13));
		address.setBounds(33, 301, 79, 24);
		JailFrame.getContentPane().add(address);
		
		txt_id = new JTextField();
		txt_id.setBounds(122, 93, 199, 19);
		JailFrame.getContentPane().add(txt_id);
		txt_id.setColumns(10);
		
		txt_hod = new JTextField();
		txt_hod.setColumns(10);
		txt_hod.setBounds(122, 136, 199, 19);
		JailFrame.getContentPane().add(txt_hod);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(122, 176, 199, 19);
		JailFrame.getContentPane().add(txt_name);
		
		txt_type = new JTextField();
		txt_type.setColumns(10);
		txt_type.setBounds(122, 219, 199, 19);
		JailFrame.getContentPane().add(txt_type);
		
		txt_contact = new JTextField();
		txt_contact.setColumns(10);
		txt_contact.setBounds(122, 260, 199, 19);
		JailFrame.getContentPane().add(txt_contact);
		
		txt_address = new JTextField();
		txt_address.setColumns(10);
		txt_address.setBounds(122, 305, 199, 19);
		JailFrame.getContentPane().add(txt_address);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(363, 33, 589, 515);
		JailFrame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Personid=Integer.parseInt((String) table.getValueAt(table.getSelectedRow(),0));
					 conn c1 = new conn();
					 String str="select * from jailtable where id="+Personid;
					 ResultSet rs = c1.s.executeQuery(str); 
					 if(rs.next())
					 {
						 txt_hod.setText(rs.getString(2));
						 txt_name.setText(rs.getString(3));
						 txt_type.setText(rs.getString(4));
						 txt_contact.setText(rs.getString(5));
						 txt_address.setText(rs.getString(6));
					 }
					}
					  catch (Exception exception) {
		                    exception.printStackTrace();
		                }
				DefaultTableModel model=(DefaultTableModel)table.getModel();
	      		
	      		String id=model.getValueAt(table.getSelectedRow(), 0).toString();
	      		String hod=model.getValueAt(table.getSelectedRow(), 1).toString();
	      		String name=model.getValueAt(table.getSelectedRow(), 2).toString();
	      		String type=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		String contact=model.getValueAt(table.getSelectedRow(), 4).toString();
	      		String address=model.getValueAt(table.getSelectedRow(), 5).toString();
	      		
	      		txt_id.setText(id);
	      		txt_hod.setText(hod);
	      		txt_name.setText(name);
	      		txt_type.setText(type);
	      		txt_contact.setText(contact);
	      		txt_address.setText(address);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "HeadOfDept", "Name", "Type", "Contact", "Address"
			}
		));
		table.setForeground(new Color(0, 0, 0));
		scrollPane.setViewportView(table);
		
		final JButton btnInsert = new JButton("Submit");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
	               	 conn c2 = new conn();
	               	    String id = txt_id.getText();
	                    String hod = txt_hod.getText();
	                    String name = txt_name.getText();
	                    String type = txt_type.getText();
	                    String contact = txt_contact.getText();
	                    String address = txt_address.getText();
	                  
	                String str =  "INSERT INTO jailtable values('" + id + "','" + hod + "','" + name +  "','"  + type+ "','" + contact + "','" + address + "')";
	                if(txt_id.getText().equals("") || txt_hod.getText().equals("")|| txt_name.getText().equals("") || txt_type.getText().equals("") || txt_contact.getText().equals("")|| txt_address.getText().equals(""))
					{
						JOptionPane.showMessageDialog(btnInsert,"Please Enter All Data");
					}
	               else {
	                    ResultSet rs = c2.s.executeQuery(str);  
	            		String data[]= {txt_id.getText(),txt_hod.getText(),txt_name.getText(),txt_type.getText(),txt_contact.getText(),txt_address.getText()};
						if(!Pattern.matches("^[0-9]+$",txt_contact.getText()))
						{
							 JOptionPane.showMessageDialog(btnInsert, "Enter a valid mobile number");
						}
						else {
	                    DefaultTableModel model=(DefaultTableModel)table.getModel();
	    				model.addRow(data);
	    				JOptionPane.showMessageDialog(btnInsert, "Added Successfully");
						}
						}
	            	txt_id.setText("");
					txt_hod.setText("");
					txt_name.setText("");
				    txt_type.setText("");
					txt_contact.setText("");
					txt_address.setText("");
	                
	               }
	               catch (Exception exception) {
	                   exception.printStackTrace();
	               }
					
			}
		});
		btnInsert.setBounds(27, 366, 95, 45);
		JailFrame.getContentPane().add(btnInsert);
		
		final JButton btnUpdate = new JButton("Modify");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Personid!=0)
				{
					String HeadOfdepartment=txt_hod.getText();
					String name=txt_name.getText();
					String type=txt_type.getText();
					String contact=txt_contact.getText();
					String address=txt_address.getText();
					
					try {  
						 conn c1 = new conn();
						 String sql="update jailtable set HeadOfdepartment='"+HeadOfdepartment+"',name='"+name+"',type='"+type+"',contact='"+contact+"',address='"+address+"' where id="+Personid;
						  ResultSet rs = c1.s.executeQuery(sql);  
							JOptionPane.showMessageDialog(btnUpdate, "Updated Successfully");
						    int row=table.getSelectedRow();
			                String cell=table.getModel().getValueAt(row, 0).toString();
			                 String str1 =  "DELETE FROM jailtable WHERE id ="+cell;
			                 conn c2 = new conn();
			                     ResultSet rs1 = c2.s.executeQuery(str1);  
			                    DefaultTableModel model=(DefaultTableModel)table.getModel();
			                    model.removeRow(table.getSelectedRow());

						     String data[]= {txt_id.getText(),txt_hod.getText(),txt_name.getText(),txt_type.getText(),txt_contact.getText(),txt_address.getText()};
		     				model.addRow(data);
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					} 
				}	
			}
		});
		btnUpdate.setBounds(182, 366, 95, 45);
		JailFrame.getContentPane().add(btnUpdate);
		
		final JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
		                int row=table.getSelectedRow();
		                String cell=table.getModel().getValueAt(row, 0).toString();
		                 String str =  "DELETE FROM jailtable WHERE id ="+cell; 
		                     ResultSet rs = c1.s.executeQuery(str);  
		                    DefaultTableModel model=(DefaultTableModel)table.getModel();
		                    model.removeRow(table.getSelectedRow());
		     				JOptionPane.showMessageDialog(btnDelete, "Deleted Successfully");
		     				
		     				txt_id.setText("");
							txt_hod.setText("");
							txt_name.setText("");
						    txt_type.setText("");
							txt_contact.setText("");
							txt_address.setText("");
		                }
		                catch (Exception exception) {
		                    exception.printStackTrace();
		                }
			}
		});
		btnDelete.setBounds(27, 446, 95, 45);
		JailFrame.getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage hp=new HomePage();
				hp.HomePage.setVisible(true);
				JailFrame.dispose();
			}
		});
		btnBack.setBounds(105, 520, 108, 45);
		JailFrame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel = new JLabel("JAIL DATABASE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(33, 20, 188, 45);
		JailFrame.getContentPane().add(lblNewLabel);
		
		JButton btnAlldetails = new JButton("AllDetails");
		btnAlldetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
	                 String str =  "select * from jailtable";
	                     ResultSet rs = c1.s.executeQuery(str);  
	                     DefaultTableModel model=(DefaultTableModel)table.getModel();
             			model.setRowCount(0);
             			  while(rs.next())
             			  {
             				  model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)});
             			  }
	                }
	                catch (Exception exception) {
	                    exception.printStackTrace();
	                }
			}
		});
		btnAlldetails.setBounds(182, 446, 95, 45);
		JailFrame.getContentPane().add(btnAlldetails);
	}

}
