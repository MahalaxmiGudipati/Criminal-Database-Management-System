import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PoliceTable {

	 JFrame PoliceFrame;
	 private JTextField txt_id;
	 private JTextField txt_name;
	 private JTextField txt_territoryname;
	 private JTextField txt_city;
	 private JTextField txt_state;
	 private JTextField txt_country;
	 private JTable table;
	 private int Personid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PoliceTable window = new PoliceTable();
					window.PoliceFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PoliceTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		PoliceFrame = new JFrame();
		PoliceFrame.getContentPane().setBackground(new Color(175, 238, 238));
		PoliceFrame.setBounds(100, 100, 980, 654);
		PoliceFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		PoliceFrame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 966, 10);
		PoliceFrame.getContentPane().add(panel);
		
		JLabel stationid = new JLabel("StationID :");
		stationid.setFont(new Font("Tahoma", Font.PLAIN, 13));
		stationid.setBounds(36, 83, 95, 24);
		PoliceFrame.getContentPane().add(stationid);
		
		JLabel stationname = new JLabel("StationName :");
		stationname.setFont(new Font("Tahoma", Font.PLAIN, 13));
		stationname.setBounds(36, 128, 95, 24);
		PoliceFrame.getContentPane().add(stationname);
		
		JLabel territoryname = new JLabel("TerritoryName :");
		territoryname.setFont(new Font("Tahoma", Font.PLAIN, 13));
		territoryname.setBounds(22, 175, 95, 24);
		PoliceFrame.getContentPane().add(territoryname);
		
		JLabel city = new JLabel("City :");
		city.setFont(new Font("Tahoma", Font.PLAIN, 13));
		city.setBounds(36, 228, 95, 24);
		PoliceFrame.getContentPane().add(city);
		
		JLabel state = new JLabel("State :");
		state.setFont(new Font("Tahoma", Font.PLAIN, 13));
		state.setBounds(36, 278, 95, 24);
		PoliceFrame.getContentPane().add(state);
		
		JLabel country = new JLabel("Country :");
		country.setFont(new Font("Tahoma", Font.PLAIN, 13));
		country.setBounds(36, 326, 95, 24);
		PoliceFrame.getContentPane().add(country);
		
		txt_id = new JTextField();
		txt_id.setBounds(125, 87, 184, 19);
		PoliceFrame.getContentPane().add(txt_id);
		txt_id.setColumns(10);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(125, 132, 184, 19);
		PoliceFrame.getContentPane().add(txt_name);
		
		txt_territoryname = new JTextField();
		txt_territoryname.setColumns(10);
		txt_territoryname.setBounds(125, 179, 184, 19);
		PoliceFrame.getContentPane().add(txt_territoryname);
		
		txt_city = new JTextField();
		txt_city.setColumns(10);
		txt_city.setBounds(125, 232, 184, 19);
		PoliceFrame.getContentPane().add(txt_city);
		
		txt_state = new JTextField();
		txt_state.setColumns(10);
		txt_state.setBounds(125, 282, 184, 19);
		PoliceFrame.getContentPane().add(txt_state);
		
		txt_country = new JTextField();
		txt_country.setColumns(10);
		txt_country.setBounds(125, 330, 184, 19);
		PoliceFrame.getContentPane().add(txt_country);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(349, 54, 593, 553);
		PoliceFrame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Personid=Integer.parseInt((String) table.getValueAt(table.getSelectedRow(),0));
					 conn c1 = new conn();
					 String str="select * from policestationtable where stationid="+Personid;
					 ResultSet rs = c1.s.executeQuery(str); 
					 if(rs.next())
					 {
						 txt_name.setText(rs.getString(2));
						 txt_territoryname.setText(rs.getString(3));
						 txt_city.setText(rs.getString(4));
						 txt_state.setText(rs.getString(5));
						 txt_country.setText(rs.getString(6));
					 }
					}
					  catch (Exception exception) {
		                    exception.printStackTrace();
		                }
					DefaultTableModel model=(DefaultTableModel)table.getModel();
	      		
	      		String stationid=model.getValueAt(table.getSelectedRow(), 0).toString();
	      		String stationname=model.getValueAt(table.getSelectedRow(), 1).toString();
	      		String territoryname=model.getValueAt(table.getSelectedRow(), 2).toString();
	      		String city=model.getValueAt(table.getSelectedRow(), 3).toString();
	      		String state=model.getValueAt(table.getSelectedRow(), 4).toString();
	      		String country=model.getValueAt(table.getSelectedRow(), 5).toString();
	      		
	      		txt_id.setText(stationid);
	      		txt_name.setText(stationname);
	      		txt_territoryname.setText(territoryname);
	      		txt_city.setText(city);
	      		txt_state.setText(state);
	      		txt_country.setText(country);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"StationID", "StationName", "TerritoryName", "City", "State", "Country"
			}
		));
		scrollPane.setViewportView(table);
		
		final JButton btnInsert = new JButton("Submit");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
                	 conn c2 = new conn();
                	 String id = txt_id.getText();
                     String name = txt_name.getText();
                     String territoryname = txt_territoryname.getText();
                     String city = txt_city.getText();
                     String state = txt_state.getText();
                     String country = txt_country.getText();
                     
                 String str =  "INSERT INTO policestationtable values('" + id + "','" + name + "','" + territoryname +  "','" 
                 + city + "','" + state + "','" + country + "')";
                 if(txt_id.getText().equals("") || txt_name.getText().equals("") || txt_territoryname.getText().equals("")||
 						 txt_city.getText().equals("")|| txt_state.getText().equals("")|| txt_country.getText().equals(""))
 				{
 					JOptionPane.showMessageDialog(btnInsert,"Please Enter All Data");
 				}
                else {
                     ResultSet rs = c2.s.executeQuery(str);  
                     String data[]= {txt_id.getText(),txt_name.getText(),txt_territoryname.getText(),
                    		 txt_city.getText(),txt_state.getText(),txt_country.getText()};
                     DefaultTableModel model=(DefaultTableModel)table.getModel();
     				model.addRow(data);
     				JOptionPane.showMessageDialog(btnInsert, "Added Successfully");
     				
     				txt_id.setText("");
					txt_name.setText("");
					txt_territoryname.setText("");
					txt_city.setText("");
					txt_state.setText("");
					txt_country.setText("");
                 }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
			}
		});
		btnInsert.setBounds(22, 396, 95, 35);
		PoliceFrame.getContentPane().add(btnInsert);
		
		final JButton btnUpdate = new JButton("Modify");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Personid!=0)
				{
					String stationname=txt_name.getText();
					String territoryname=txt_territoryname.getText();
					String city=txt_city.getText();
					String state=txt_state.getText();
					String country=txt_country.getText();
					try {  
						 conn c1 = new conn();
						 String sql="update policestationtable set stationname='"+stationname+"',territoryname='"+territoryname+"',city='"+city+"',state='"+state+"',country='"+country+"' where stationid="+Personid;
						  ResultSet rs = c1.s.executeQuery(sql);  
							JOptionPane.showMessageDialog( btnUpdate, "Updated Successfully");
						    int row=table.getSelectedRow();
			                String cell=table.getModel().getValueAt(row, 0).toString();
			                 String str1 =  "DELETE FROM policestationtable WHERE stationid ="+cell;
			                 conn c2 = new conn();
			                     ResultSet rs1 = c2.s.executeQuery(str1);  
			                    DefaultTableModel model=(DefaultTableModel)table.getModel();
			                    model.removeRow(table.getSelectedRow());

						     String data[]= {txt_id.getText(),txt_name.getText(),txt_territoryname.getText(),txt_city.getText(),txt_state.getText(),txt_country.getText()};
		     				model.addRow(data);
					}
					catch (SQLException e1) {
						e1.printStackTrace();
					} 
	      		}
			}
		});
		btnUpdate.setBounds(176, 396, 95, 35);
		PoliceFrame.getContentPane().add(btnUpdate);
		
		final JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
		                int row=table.getSelectedRow();
		                String cell=table.getModel().getValueAt(row, 0).toString();
		                 String str =  "DELETE FROM policestationtable WHERE stationid="+cell; 
		                     ResultSet rs = c1.s.executeQuery(str);  
		                    DefaultTableModel model=(DefaultTableModel)table.getModel();
		                    model.removeRow(table.getSelectedRow());
		     				JOptionPane.showMessageDialog(btnDelete, "Deleted Successfully");
		     				
		     				txt_id.setText("");
							txt_name.setText("");
							txt_territoryname.setText("");
							txt_city.setText("");
							txt_state.setText("");
							txt_country.setText("");
		                }
		                catch (Exception exception) {
		                    exception.printStackTrace();
		                }
			}
		});
		btnDelete.setBounds(22, 474, 95, 35);
		PoliceFrame.getContentPane().add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				HomePage hp=new HomePage();
				hp.HomePage.setVisible(true);
				PoliceFrame.dispose();
			}
		});
		btnBack.setBounds(112, 547, 95, 35);
		PoliceFrame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("POLICE STATION DATABASE");
		lblNewLabel_1.setBackground(new Color(100, 149, 237));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_1.setBounds(36, 30, 303, 35);
		PoliceFrame.getContentPane().add(lblNewLabel_1);
		
		JButton btnAlldata = new JButton("AllDetails");
		btnAlldata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
					 conn c1 = new conn();
	                 String str =  "select * from policestationtable";
	                     ResultSet rs = c1.s.executeQuery(str);  
	                     DefaultTableModel model=(DefaultTableModel)table.getModel();
             			model.setRowCount(0);
             			  while(rs.next())
             			  {
             				  model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)});
             			  }
	                }
	                catch (Exception exception) {
	                    exception.printStackTrace();
	                }
			}
		});
		btnAlldata.setBounds(176, 474, 95, 35);
		PoliceFrame.getContentPane().add(btnAlldata);
	}
}
