import java.sql.*;
 class conn {

	  Connection c;
	    Statement s;
	    public conn()
	    {  
	        try{
	           
	        	 c = DriverManager.getConnection( "jdbc:oracle:thin:@localhost:1521:xe","it19737045","vasavi");   
		            s =c.createStatement(); 
	           
	            }catch(Exception e){
	                System.out.println(e);
	        }  
	    } 
	}
